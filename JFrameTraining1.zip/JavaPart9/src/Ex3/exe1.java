package Ex3;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class exe1 extends JFrame {
	public exe1() {
		setTitle("�� �ϱ�Ⱦ�");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Container a = getContentPane();

		a.add(new JButton("Hello"));

		setSize(200, 150);
		setVisible(true);
	}

	public static void main(String[] args) {
		new exe1();
	}

}
